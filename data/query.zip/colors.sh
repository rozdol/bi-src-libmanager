#!/bin/bash
#set -e
RED='\e[0;31m'
GRE='\e[0;32m'
ORG='\e[0;33m'
BLU='\e[0;34m'
BLE='\e[0;36m'
NC='\e[0;39m' # No Color

curr_dir=$(pwd);
cd ..;
prent_dir=$(pwd);
cd $curr_dir;
