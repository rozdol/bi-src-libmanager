#!/bin/bash
my_dir="$(dirname "$0")"
source  "$my_dir/colors.sh"
KEY_FILE="$my_dir/key.tmp"
access_token=`cat $KEY_FILE`
# printf "${GRE}STARTED ${NC}\n";

user=$1
pass=$2

url="http://is.local.lan/?act=api"
func="test_api"
func="get_companies"
func=$3
table=$4


function get_json {
    temp=`echo $curl_rq`
    echo ${temp##*|}
    #echo ${temp}
}

function generate_post_data()
{
  cat <<EOF
{
  "user":"$user",
  "api_key":"$key",
  "func":"$func",
  "table":"$table",
  "fields":"id,name",
  "filters":"id > 2",
  "_id":"10",
  "_email":"emailtest2a@mailinator.com"
}
EOF
}

function generate_post_data2()
{
  cat <<EOF
{
  "user":"$user",
  "api_key":"$key",
  "func":"$func",
  "id":"222",
  "email": "email@server.com",
  "values":"{\"session_name\":\"SessionTest\", \"session_name2\":\"SessionTest2\"}"
}
EOF
}

function get_key()
{
  user=$1
  pass=$2
  echo $user $pass
  curl_rq=`curl -s -H "Content-Type: application/json" -H "Accept: application/json" -X POST -d '{"user":"'$user'","pass":"'$pass'"}' $url`
  json=`get_json`

  error=`echo "$json" | jq  -r '.error'`

  if [[ "$error" != "null" ]]; then
    printf "AUTH:${RED}$error ${NC}\n";
    echo "RESP:$json"
    exit
  fi


  key=`echo "$json" | jq  -r '.api_key'`
  access_token=`echo "$json" | jq  -r '.access_token'`
  echo $access_token > $KEY_FILE
  #return $access_token
}

if [[ "$access_token" == "" ]]; then
  get_key $user $pass
  printf "GET KEY:${RED}$access_token  ${NC}\n";
fi
#echo $access_token
get_key $user $pass
#key=`cat $KEY_FILE`
#access_token='Bearer '
#echo $access_token

function try_query()
{
  # get_key $user $pass
  # key=`cat $KEY_FILE`
  access_token=`cat $KEY_FILE`

  curl_rq=`curl -s -H "Content-Type: application/json" -H "Accept: application/json" -H "Authorization: Bearer $access_token" -X POST -d ''"$post_data"''  $url`
  json=`get_json`
  echo "J:$json"
  error=`echo "$json" | jq  -r '.error'`

  if [[ "$error" != "null" ]]; then
    printf "ERR:${RED}$error ${NC}\n";
    if [[ "$error" == "No access_token string supplied" ]]; then
      get_key $user $pass
      $access_token=`cat $KEY_FILE`
      try_query
    fi
    exit
  fi

  echo "$json" | jq  -r '.'
}

post_data=`generate_post_data`
try_query
#echo "D:$post_data"
# exit;



